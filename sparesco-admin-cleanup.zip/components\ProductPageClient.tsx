"use client";

import { useEffect, useState } from "react";
import type { Product } from "@/types/product";
import { useEnquiry } from "@/context/EnquiryContext";
import ProductFaqTrustSection from "@/components/ProductFaqTrustSection";
import RecentlyViewed from "@/components/RecentlyViewed";

function cleanVariantTitle(title: string) {
  return title
    .split("| Replaces")[0]
    .split("| replaces")[0]
    .split(" Replaces")[0]
    .split(" replaces")[0]
    .trim();
}

function getCleanSpecs(specifications: string[]) {
  return specifications.filter((spec) => {
    if (!spec.includes(":")) return false;

    const [label, ...valueParts] = spec.split(":");
    const cleanLabel = label.trim();
    const cleanValue = valueParts.join(":").trim();

    return cleanLabel && cleanValue && cleanLabel.length <= 45;
  });
}

function cleanText(value?: string) {
  return (value || "").replace(/\s+/g, " ").trim();
}

function replaceFilterFinder(value?: string) {
  if (!value) return "";

  let text = String(value);

  // Remove sentences that would create false distributor/authorisation claims
  text = text.replace(
    /[^.!?]*(?:filter\s*finder|filterfinder)[^.!?]*(?:approved|authorised|authorized|official)\s+(?:distributor|dealer|supplier|partner)[^.!?]*[.!?]?/gi,
    " "
  );

  text = text.replace(
    /[^.!?]*(?:approved|authorised|authorized|official)\s+(?:distributor|dealer|supplier|partner)[^.!?]*(?:filter\s*finder|filterfinder)[^.!?]*[.!?]?/gi,
    " "
  );

  // Replace FilterFinder URLs with Sparesco
  text = text.replace(
    /https?:\/\/(?:www\.)?filterfinder\.[^\s]+/gi,
    "https://sparesco.com"
  );

  text = text.replace(
    /www\.filterfinder\.[^\s]+/gi,
    "sparesco.com"
  );

  // Replace normal brand-name references
  text = text.replace(/\bfilter\s*finder\b/gi, "Sparesco");
  text = text.replace(/\bfilterfinder\b/gi, "Sparesco");

  return text
    .replace(/â€™/g, "’")
    .replace(/â€œ/g, "“")
    .replace(/â€/g, "”")
    .replace(/â€“/g, "–")
    .replace(/â€”/g, "—")
    .replace(/\s+/g, " ")
    .replace(/\s+([.,;:!?])/g, "$1")
    .trim();
}

function getProductImageAlt(
  productTitle: string,
  variantTitle: string,
  vendor: string,
  partNumber: string
) {
  const reference = cleanText(productTitle).toUpperCase();
  const cleanVendor = cleanText(vendor);
  const cleanPartNumber = cleanText(partNumber);
  const cleanTitle = cleanText(variantTitle);

  const details = [
    cleanVendor,
    cleanPartNumber,
    cleanTitle,
  ].filter(Boolean);

  if (!details.length) return reference || "Spare part";

  return `${reference} - ${details.join(" ")}`;
}

export default function ProductPageClient({
  handle,
  initialProduct,
}: {
  handle: string;
  initialProduct?: Product | null;
}) {
  const { addItem } = useEnquiry();

  const [product, setProduct] = useState<Product | null>(
    initialProduct || null
  );
  const [loaded, setLoaded] = useState(Boolean(initialProduct));
  const [galleryImages, setGalleryImages] = useState<string[]>(
    initialProduct?.images || []
  );

  const [activeImage, setActiveImage] = useState(
    initialProduct?.images?.[0] || ""
  );
  const [activeVariantIndex, setActiveVariantIndex] = useState(0);
  const [specsOpen, setSpecsOpen] = useState(false);
  const [descriptionOpen, setDescriptionOpen] = useState(false);

  useEffect(() => {
    if (initialProduct) {
      const images = initialProduct.images || [];

      setProduct(initialProduct);
      setGalleryImages(images);
      setActiveImage(images[0] || "");
      setLoaded(true);

      return;
    }

    fetch(`/api/product/${handle}`, {
      cache: "no-store",
    })
      .then((res) => {
        if (!res.ok) throw new Error("Product not found");
        return res.json();
      })
      .then((data: Product) => {
        setProduct(data);

        const images = data.images || [];

        setGalleryImages(images);
        setActiveImage(images[0] || "");
      })
      .catch(() => setProduct(null))
      .finally(() => setLoaded(true));
  }, [handle, initialProduct]);

  if (!loaded) {
    return (
      <main>
        <section className="section product-page-section">
          <div className="container">
            <div className="product-page-layout product-redesign-layout">
              <div className="product-gallery product-gallery-sticky">
                <div className="main-product-image skeleton-box skeleton-pdp-image" />
              </div>

              <div className="product-redesign-details">
                <div className="skeleton-line skeleton-title" />
                <div className="skeleton-line" />
                <div className="skeleton-line" />
                <div className="skeleton-line skeleton-short" />
              </div>
            </div>
          </div>
        </section>
      </main>
    );
  }

  if (!product) {
    return (
      <main>
        <section className="section">
          <div className="container">
            <h1>Product not found</h1>
          </div>
        </section>
      </main>
    );
  }

  const currentProduct = product;
  const activeVariant = currentProduct.variants[activeVariantIndex];

  if (!activeVariant) return null;

  const r2Base = process.env.NEXT_PUBLIC_R2_PUBLIC_URL?.replace(/\/$/, "");
  const imageFolder =
    currentProduct.imageFolder || currentProduct.collection || currentProduct.category || "";

  const imageBase =
    r2Base && imageFolder
      ? `${r2Base}/catalog/images/${imageFolder}/`
      : "";

  function getImageUrl(image: string) {
    if (!image) return "";
    return image.startsWith("http") ? image : `${imageBase}${image}`;
  }

  const primaryVariant =
    currentProduct.variants?.[0];

  const primaryVariantTitle =
    replaceFilterFinder(
      cleanVariantTitle(
        primaryVariant?.title ||
        currentProduct.title ||
        currentProduct.handle
      )
    );

  const activeVariantTitle = replaceFilterFinder(
    cleanVariantTitle(activeVariant.title)
  );

  const productReference = replaceFilterFinder(
    cleanText(currentProduct.title || currentProduct.handle)
  );

  const selectedVariantReference =
    cleanText(activeVariant.partNumber) ||
    activeVariantTitle;

  const displayProductTitle =
    selectedVariantReference &&
      selectedVariantReference.toLowerCase() !==
      productReference.toLowerCase()
      ? `${productReference} - ${selectedVariantReference}`
      : productReference;

  const productImageAlt = getProductImageAlt(
    productReference,
    activeVariantTitle,
    activeVariant.vendor,
    activeVariant.partNumber
  );

  const activePrice =
    activeVariant.price > 0
      ? `₹${activeVariant.price.toLocaleString("en-IN")}`
      : "Price On Request";

  const stickyImage =
    activeVariant.image || activeImage || currentProduct.images?.[0] || "";

  const specs = Array.from(
    new Set(
      [
        `Part Number: ${activeVariant.partNumber}`,
        activeVariant.hsCode ? `HS Code: ${activeVariant.hsCode}` : "",
        activeVariant.countryOfOrigin
          ? `Country of Origin: ${activeVariant.countryOfOrigin}`
          : "",
        activeVariant.unitWeight
          ? `Unit Weight: ${activeVariant.unitWeight}`
          : "",
        activeVariant.shippingVolume
          ? `Shipping Volume: ${activeVariant.shippingVolume}`
          : "",
        ...getCleanSpecs(activeVariant.specifications || []).map((spec) =>
          replaceFilterFinder(spec)
        ),
      ].filter(Boolean)
    )
  );

  function addActiveVariantToEnquiry() {
    const cleanPartNumber = activeVariant.partNumber || ""
    const cleanVariantName = activeVariantTitle || "";

    addItem({
      id: `${currentProduct.handle}-${cleanPartNumber}`,
      handle: currentProduct.handle,
      title: displayProductTitle,
      variantDescription: activeVariantTitle,
      image: getImageUrl(stickyImage),
      partNumber: cleanPartNumber,
      vendor:
        activeVariant.vendor ||
        currentProduct.collection ||
        currentProduct.category ||
        "",
      price: activeVariant.price || 0,
    });
  }

  return (
    <main>
      <section className="section product-page-section">
        <div className="container">
          <div className="product-page-layout product-redesign-layout">
            <div className="product-gallery product-gallery-sticky">
              <div className="main-product-image">
                {activeImage ? (
                  <img
                    src={getImageUrl(activeImage)}
                    alt={productImageAlt}
                    onError={(e) => {
                      e.currentTarget.onerror = null;
                      e.currentTarget.src = "/images/product-placeholder.webp";
                    }}
                  />
                ) : (
                  <img
                    src="/images/product-placeholder.webp"
                    alt={productImageAlt}
                  />
                )}
              </div>

              {galleryImages.length > 0 && (
                <div className="thumbnail-row">
                  {galleryImages.map((image) => (
                    <button
                      key={image}
                      type="button"
                      className={
                        activeImage === image ? "thumbnail active" : "thumbnail"
                      }
                      onClick={() => setActiveImage(image)}
                    >
                      <img
                        src={getImageUrl(image)}
                        alt={`${productImageAlt} product image`}
                        onError={(e) => {
                          e.currentTarget.onerror = null;
                          e.currentTarget.src = "/images/product-placeholder.webp";
                        }}
                      />
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="product-redesign-details">
              <div className="product-heading-block">
                <div className="product-title-price-row">
                  <div className="selected-variant-name">
                    {activeVariant.partNumber || activeVariantTitle}
                  </div>

                  <div className="product-top-price">{activePrice}</div>
                </div>

                <h1 className="product-title">
                  {displayProductTitle}
                </h1>
              </div>

              <div className="variant-section">
                {currentProduct.variants.length > 1 && (
                  <div className="variant-section-heading">
                    Available References for{" "}
                    {primaryVariant?.partNumber ||
                      currentProduct.title}
                  </div>
                )}

                <div className="variant-list variant-list-two-column">
                  {currentProduct.variants.map((variant, index) => (
                    <button
                      key={variant.sku || `${variant.partNumber}-${index}`}
                      type="button"
                      className={
                        index === activeVariantIndex
                          ? "variant-card variant-card-simple active"
                          : "variant-card variant-card-simple"
                      }
                      onClick={() => {
                        setActiveVariantIndex(index);
                        setSpecsOpen(false);
                        setDescriptionOpen(false);
                        if (variant.image) setActiveImage(variant.image);
                      }}
                    >
                      <span>
                        {replaceFilterFinder(
                          cleanVariantTitle(variant.title)
                        )}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="product-specs-panel">
                <button
                  type="button"
                  className="product-section-header"
                  onClick={() => setSpecsOpen((current) => !current)}
                >
                  <span>Technical Specifications</span>
                  <strong>{specsOpen ? "−" : "+"}</strong>
                </button>

                <div
                  className={
                    specsOpen
                      ? "specification-table product-specs-preview open"
                      : "specification-table product-specs-preview closed"
                  }
                >
                  {specs.map((spec) => {
                    const [label, ...valueParts] = spec.split(":");
                    const cleanLabel = label.trim();
                    const cleanValue = valueParts.join(":").trim();

                    return (
                      <div key={spec}>
                        <strong>{cleanLabel}</strong>
                        <span>{cleanValue}</span>
                      </div>
                    );
                  })}

                  {!specsOpen && <div className="specs-fade" />}
                </div>
              </div>

              <div className="product-description-accordion">
                <button
                  type="button"
                  className="product-section-header"
                  onClick={() => setDescriptionOpen((current) => !current)}
                >
                  <span>Description</span>
                  <strong>{descriptionOpen ? "−" : "+"}</strong>
                </button>

                <div
                  className={
                    descriptionOpen
                      ? "product-description-box open"
                      : "product-description-box closed"
                  }
                >
                  <p>
                    {replaceFilterFinder(activeVariant.description) ||
                      "Description not available."}
                  </p>

                  {!descriptionOpen && <div className="description-fade" />}
                </div>

              </div>
            </div>
          </div>
        </div>
        <ProductFaqTrustSection onRequestQuote={addActiveVariantToEnquiry} />
        <RecentlyViewed currentHandle={currentProduct.handle} />
      </section>

      <div className="sticky-enquiry-bar">
        <div className="sticky-enquiry-inner">
          <div className="sticky-selected-variant">
            <div className="sticky-selected-image">
              {stickyImage ? (
                <img
                  src={getImageUrl(stickyImage)}
                  alt={productImageAlt}
                  onError={(event) => {
                    event.currentTarget.onerror = null;
                    event.currentTarget.src = "/images/product-placeholder.webp";
                  }}
                />
              ) : null}
            </div>

            <div>
              <span>Selected Variant</span>
              <strong>{displayProductTitle}</strong>
            </div>
          </div>

          <div className="sticky-enquiry-actions">
            <strong>{activePrice}</strong>

            <button
              type="button"
              className="primary-button"
              onClick={addActiveVariantToEnquiry}
            >
              Add To Enquiry
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}